// This file is no longer needed - using default Password provider
