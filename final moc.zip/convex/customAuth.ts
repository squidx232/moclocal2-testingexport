// This file is no longer used - we're using simpleAuth.ts instead
export {};
